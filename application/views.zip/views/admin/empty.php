<div id="page-wrapper">
	
	<?php 
	// var_dump(config_item('rules') );
	// echo get_config('my_menu') ;
	// var_dump($this->session->userdata) ;
	// echo site_url();
	var_dump(img2shortcode(__l('my_form_alaki')));
	shortcode2img(img2shortcode(__l('my_form_alaki'))) ;

	; ?>
</div>