<!DOCTYPE html>
<html>
<head>
	<title>alaki</title>
	<style type="text/css">
	p{
		display: inline;
	}
	</style>
</head>
<body dir="rtl" style="font-family:tahoma;">
<?php 
echo '<p>' . $number . '- '. $text . '</p><br/><br/>';
echo '<p> a - '. $a . '</p><br/><br/>';
echo '<p> b - '. $b . '</p><br/><br/>';
echo '<p> c - '. $c . '</p><br/><br/>';
echo '<p> d - '. $d . '</p><br/><br/>';
?>
</body>
</html>