<?php
/**
* Created By Reza Bidar 
* my navbar lang 
*/

$lang['my_navbar_dashboard'] = 'داشبورد' ;

$lang['my_navbar_questions'] = 'سوالات' ;
$lang['my_navbar_add_question'] = 'اضافه کردن' ;
$lang['my_navbar_question_list'] = 'لیست' ;
$lang['my_navbar_my_question_list'] = 'لیست من' ;

$lang['my_navbar_charts'] = 'چارت تحصیلی' ;
$lang['my_navbar_add_chartpg'] = 'اضافه کردن' ;
$lang['my_navbar_chartpg_list'] = 'لیست' ;

$lang['my_navbar_users'] = 'کاربران سایت' ;
$lang['my_navbar_add_user'] = 'اضافه کردن' ;
$lang['my_navbar_user_list'] = 'لیست' ;

$lang['my_navbar_lessons'] = 'درسها' ;
$lang['my_navbar_add_lesson'] = 'اضافه کردن' ;
$lang['my_navbar_add_group_lesson'] = 'اضافه کردن گروهی' ;
$lang['my_navbar_lesson_list'] = 'لیست' ;
$lang['my_navbar_my_lesson_list'] = 'لیست من' ;

$lang['my_navbar_universities'] = 'دانشگاه ها' ;
$lang['my_navbar_add_university'] = 'اضافه کردن' ;
$lang['my_navbar_university_list'] = 'لیست' ;

$lang['my_navbar_majors'] = 'رشته ها' ;
$lang['my_navbar_add_major'] = 'اضافه کردن' ;
$lang['my_navbar_major_list'] = 'لیست' ;


$lang['my_navbar_terms'] = 'ترم ها' ;
$lang['my_navbar_add_term'] = 'اضافه کردن' ;
$lang['my_navbar_term_list'] = 'لیست' ;

$lang['my_navbar_students'] = 'دانشجویان' ;

$lang['my_navbar_reports'] = 'گزارشات کاربران' ;
