<?php
/**
* created by Reza Bidar
*/

$lang['my_page_add_user'] = 'اضافه کردن کاربر' ;
$lang['my_page_user_list'] = 'لیست کاربران سایت' ;
$lang['my_page_edit_user'] = 'ویرایش کاربر' ;
$lang['my_page_add_university'] = 'اضافه کردن دانشگاه' ;
$lang['my_page_edit_university'] = 'ویرایش دانشگاه' ;
$lang['my_page_university_list'] = 'لیست دانشگاه ها' ;
$lang['my_page_add_term'] = 'اضافه کردن ترم' ;
$lang['my_page_edit_term'] = 'ویرایش ترم' ;
$lang['my_page_term_list'] = 'لیست ترم ها' ;
$lang['my_page_add_lesson'] = 'اضافه کردن درس' ;
$lang['my_page_lesson_list'] = 'لیست درس ها' ;
$lang['my_page_my_lesson_list'] = 'لیست درس های من' ;
$lang['my_page_lesson_possible_add'] = 'شناسایی دروس جدید' ;
$lang['my_page_add_major'] = 'اضافه کردن رشته' ;
$lang['my_page_edit_major'] = 'ویرایش رشته' ;
$lang['my_page_major_list'] = 'لیست رشته ها' ;
$lang['my_page_add_qpage'] = 'اضافه کردن برگه سوال' ;
$lang['my_page_edit_qpage'] = 'ویرایش برگه ی سوال' ;
$lang['my_page_qpage_list'] = 'لیست سوالات' ;
$lang['my_page_my_qpage_list'] = 'لیست سوالات من' ;
$lang['my_page_qpage_review'] = 'نمای کامل برگه ی سوال' ;
$lang['my_page_add_question'] = 'سوال جدید' ;
$lang['my_page_question_list'] = 'لیست سوالات' ;
$lang['my_page_add_chartpage'] = 'چارت جدید' ;
$lang['my_page_chartpage_list'] = 'لیست چارت تحصیلی' ;
$lang['my_page_add_chart_content'] = 'اضافه کردن درس در چارت' ;
$lang['my_page_chart_content_list'] = 'لیست دروس چارت' ;