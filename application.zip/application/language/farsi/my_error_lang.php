<?php
/**
* Created By Reza Bidar 
* my error lang 
*/

$lang['my_error_incorrect_user_pass'] = 'نام کاربری یا کلمه عبور اشتباه وارد شده است' ;
$lang['my_error_dont_permission_to_see_page'] = '<p>You dont have permission to see this page please call Administrator</p>' ;
$lang['my_error_transaction'] = 'مشکل در تراکنش لطفا با مدیر سایت تماس بگیرید' ;

//form validation
$lang['my_error_fv_university_unique'] = 'دانشگاه وارد شده تکراری میباشد .' ;
$lang['my_error_fv_number_in_page_unique'] = 'شماره ی سوال تکراری میباشد .' ;
$lang['my_error_fv_chartpage_unique'] = 'قبلا این چارت تحصیلی ثبت شده است .' ;