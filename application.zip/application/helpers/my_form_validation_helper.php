<?php 

// function university_unique_check($str){
	// $CI =& get_instance();

	// $CI->db->where(array(
 //                m_university::COLUMN_STATE => $CI->input->post('state') ,
 //                m_university::COLUMN_CITY => $CI->input->post('city') ,
 //       ));

	// $uni = $CI->m_university->get() ;
	// if(sizeof($uni) > 0) {
	// 	$CI->form_validation->set_message('university_unique_check' , __l('my_error_fv_university_unique')) ;
	// 	return FALSE ;
	// }
// 	return TRUE ;
	
// }