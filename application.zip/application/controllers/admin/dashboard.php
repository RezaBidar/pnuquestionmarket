<?php

class dashboard extends Admin_Controller{


	public function index(){


		$capability = CAP_PUBLIC ;
		if(!checkPermision($capability)) return ;

		$this->load->model('m_lesson');
		$this->load->model('m_question_page');
		$this->load->model('m_question');

		$this->data['question_count'] = sizeof($this->m_question->get_by([m_question::COLUMN_CREATOR => $this->data['user_id']] , FALSE , FALSE)) ;
		$this->data['qpage_count'] = sizeof($this->m_question_page->get_by([m_question_page::COLUMN_CREATOR => $this->data['user_id']] , FALSE , FALSE)) ;
		$this->data['lesson_count'] = sizeof($this->m_lesson->get_by([m_lesson::COLUMN_CREATOR => $this->data['user_id']] , FALSE , FALSE)) ;
		//$this->data['user_fullname']
		
		$this->load->view('admin/component/header');
		$this->load->view('admin/component/nav' , $this->data);
		$this->load->view('admin/dashboard');
		$this->load->view('admin/component/footer');
	}

	public function logout()
	{

		$capability = CAP_PUBLIC ;
		if(!checkPermision($capability)) return ;
		
		$this->m_user->logout();
		redirect('login');
	}
}