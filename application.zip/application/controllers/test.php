<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
* 
*/
class test extends CI_Controller 
{
	
	function index()
	{
		$data['menu'] = Navbar::getArray('admin') ;
		$this->load->view('admin/component/header');
		$this->load->view('admin/component/nav' , $data);
		$this->load->view('admin/empty');
		$this->load->view('admin/component/footer');
	}
}