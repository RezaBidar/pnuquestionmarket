
    </div>
    <!-- /#wrapper -->

    <!-- site_url for js -->
    <input name="site_url" type="hidden" value="<?php echo site_url() ?>">
    
    <!-- jQuery Version 1.11.0 -->
    <script src="<?php echo site_url('js/jquery-1.11.0.js') ?>"></script>
    


    <!-- jQuery 
    <script src="<?php echo site_url('js/jquery.js') ?>"></script> -->

    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo site_url('js/bootstrap.min.js') ?>"></script>

    <!-- TinyMCE -->
    <script src="<?php echo site_url('js/plugins/tinymce/tinymce.min.js') ?>"></script>

    <!-- Radio For Button -->
    <script src="<?php echo site_url('js/plugins/radio2button/jquery.radiosforbuttons.min.js') ?>"></script>

    <!-- Data Tables -->
    <script src="<?php echo site_url('js/plugins/dataTables/jquery.dataTables.js') ?>"></script>
    <script src="<?php echo site_url('js/plugins/dataTables/dataTables.bootstrap.js') ?>"></script>

    <!-- BootBox library -->
    <script src="<?php echo site_url('js/plugins/bootbox/bootbox.min.js') ?>" ></script>
    
    <!-- Function (my custom js) -->
    <script type="text/javascript" src="<?php echo site_url('js/functions.js') ?>"></script>
    




</body>

</html>