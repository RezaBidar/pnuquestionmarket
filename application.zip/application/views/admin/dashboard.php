<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            داشبورد
                        </h1>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-10">
                        <div class="alert alert-info">
                            <i class="fa fa-info-circle"></i>  سلام جناب <?php echo $user_fullname ?>
                        </div>
                    </div>
                </div>

                <!-- /.row -->
								<div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-print fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo $qpage_count ?></div>
                                        <div>برگه سوال ثبت شده توسط شما</div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo site_url('admin/dash_question/qpage_list/' . $user_id ) ?>">
                                <div class="panel-footer">
                                    <span class="pull-left">مشاهده لیست برگه سوال</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-question fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo $question_count ?></div>
                                        <div>سوال ثبت شده توسط شما</div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo site_url('admin/dash_question/add_qpage') ?>">
                                <div class="panel-footer">
                                    <span class="pull-left">ثبت برگه سوال جدید</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-book fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <div class="huge"><?php echo $lesson_count ?></div>
                                        <div>درس ثبت شده توسط شما</div>
                                    </div>
                                </div>
                            </div>
                            <a href="<?php echo site_url('admin/dash_lesson/lesson_list/' . $user_id) ?>">
                                <div class="panel-footer">
                                    <span class="pull-left">مشاهده لیست دروس</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
</div>